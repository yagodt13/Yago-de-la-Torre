class CartaMemoria extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: 'open' });
        this.shadowRoot.innerHTML = `
            <style>
                .carta {
                    width: 100px;
                    height: 100px;
                    background: rgb(60, 145, 236);
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    font-size: 24px;
                    cursor: pointer;
                    border-radius: 10px;
                    transition: background 0.3s ease-in-out;
                }
            </style>
            <div class="carta">?</div>
        `;
        this.carta = this.shadowRoot.querySelector('.carta'); // Elemento de la carta
        this.carta.addEventListener('click', () => this.voltear()); // Evento de clic para voltear
    }

    // Asignar el valor de la carta
    set valor(val) {
        this._valor = val;
    }

    // Función para voltear la carta
    voltear() {
        if (JuegoMemoria.parejasSeleccionadas.length < 2 && !this.carta.classList.contains('revelada')) {
            this.carta.textContent = this._valor; // Muestra el valor de la carta
            this.carta.classList.add('revelada'); // Marca la carta como revelada
            JuegoMemoria.parejasSeleccionadas.push(this); // Agrega la carta al array de selección

            if (JuegoMemoria.parejasSeleccionadas.length === 2) {
                JuegoMemoria.verificarPareja();
            }
        }
    }

    // Función para ocultar la carta si no es pareja
    ocultar() {
        this.carta.textContent = '?'; // Oculta la carta nuevamente
        this.carta.classList.remove('revelada'); // Quita la clase revelada
    }
}

// Define el nuevo elemento en el navegador
customElements.define('carta-memoria', CartaMemoria);

const JuegoMemoria = {
    parejasSeleccionadas: [], // Almacena las cartas seleccionadas temporalmente
    parejasEncontradas: 0, // Contador de parejas encontradas
    totalParejas: 6, // Total de parejas en el juego
    timeoutID: null, // Identificador del timeout
    tiempoInicio: null, // Marca de tiempo de inicio
    tiempoIntervalo: null, // Intervalo de temporizador

    esperar(ms) {
        return new Promise(resolve => {
            this.timeoutID = setTimeout(resolve, ms);
        });
    },

    // Verifica si las cartas seleccionadas son pareja
    async verificarPareja() {
        await this.esperar(1000); // Espera antes de verificar
        const [carta1, carta2] = this.parejasSeleccionadas;
        if (carta1._valor === carta2._valor) { // Si son pareja
            this.parejasEncontradas++;
            if (this.parejasEncontradas === this.totalParejas) {
                this.mostrarPantallaExito(); // Muestra éxito si todas las parejas fueron encontradas
            }
        } else { // Si no son pareja, las oculta
            carta1.ocultar();
            carta2.ocultar();
        }
        this.parejasSeleccionadas = []; // Reinicia la selección
    },

    // Cancela el timeout si es necesario
    cancelarTiempoEspera() {
        if (this.timeoutID) {
            clearTimeout(this.timeoutID);
            this.timeoutID = null;
        }
    },

    // Muestra la pantalla de éxito
    mostrarPantallaExito() {
        this.cancelarTiempoEspera(); // Cancela cualquier timeout activo
        clearInterval(this.tiempoIntervalo); // Detiene el temporizador
        document.getElementById('juego').style.display = 'none'; // Oculta el tablero
        document.getElementById('exito').style.display = 'block'; // Muestra la pantalla de éxito
        document.getElementById('tiempoFinal').textContent = `Tiempo: ${this.formatearTiempo(Date.now() - this.tiempoInicio)}`; // Muestra el tiempo final
    },

    // Función para iniciar el temporizador
    iniciarTemporizador() {
        this.tiempoInicio = Date.now(); // Marca el tiempo de inicio
        this.tiempoIntervalo = setInterval(() => {
            const tiempoTranscurrido = Date.now() - this.tiempoInicio; // Calcula el tiempo transcurrido
            const minutos = Math.floor(tiempoTranscurrido / 60000);
            const segundos = Math.floor((tiempoTranscurrido % 60000) / 1000);
            document.getElementById('tiempo').textContent = `Tiempo: ${minutos}:${segundos < 10 ? '0' : ''}${segundos}`; // Muestra el tiempo en el tablero
        }, 1000); // Actualiza cada segundo
    }
};

// Función para iniciar el juego con una promesa de carga
const iniciarJuego = async () => {
    document.getElementById('mensaje').textContent = 'Cargando cartas...'; // Muestra mensaje de carga
    await new Promise(resolve => setTimeout(resolve, 2000)); // Simula carga de cartas
    document.getElementById('mensaje').textContent = ''; // Borra el mensaje de carga
    
    const valores = ['🍎', '🍌', '🍇', '🍉', '🍓', '🍍', '🍎', '🍌', '🍇', '🍉', '🍓', '🍍'];
    valores.sort(() => Math.random() - 0.5); // Mezcla las cartas
    const tablero = document.getElementById('tablero');
    tablero.innerHTML = ''; // Limpia el tablero antes de empezar
    JuegoMemoria.parejasEncontradas = 0; // Reinicia las parejas encontradas
    JuegoMemoria.cancelarTiempoEspera(); // Cancela cualquier timeout previo

    for (let valor of valores) {
        const carta = document.createElement('carta-memoria'); // Crea una nueva carta 
        carta.valor = valor; // Asigna el tipo de carta
        tablero.appendChild(carta); // Agrega la carta al tablero
    }

    JuegoMemoria.iniciarTemporizador(); // Inicia el temporizador
};

// Para iniciar el juego pulsando el botón
document.getElementById('iniciar').addEventListener('click', () => {
    document.getElementById('inicio').style.display = 'none'; // Oculta la pantalla de inicio
    document.getElementById('juego').style.display = 'block'; // Muestra el tablero del juego
    iniciarJuego(); // Llama a la función para iniciar el juego
});
