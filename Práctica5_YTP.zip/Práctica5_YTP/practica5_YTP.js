// Componente Web para las cartas del juego
class CartaMemoria extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: 'open' });
        this.shadowRoot.innerHTML = `
            <style>
                .carta {
                    width: 100px;
                    height: 100px;
                    background: lightblue;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    font-size: 24px;
                    cursor: pointer;
                    border-radius: 10px;
                }
            </style>
            <div class="carta">?</div>
        `;
        this.carta = this.shadowRoot.querySelector('.carta');
        this.carta.addEventListener('click', () => this.voltear());
    }

    set valor(val) {
        this._valor = val;
    }

    voltear() {
        if (JuegoMemoria.parejasSeleccionadas.length < 2 && !this.carta.classList.contains('revelada')) {
            this.carta.textContent = this._valor;
            this.carta.classList.add('revelada');
            JuegoMemoria.parejasSeleccionadas.push(this);

            if (JuegoMemoria.parejasSeleccionadas.length === 2) {
                setTimeout(() => JuegoMemoria.verificarPareja(), 1000);
            }
        }
    }

    ocultar() {
        this.carta.textContent = '?';
        this.carta.classList.remove('revelada');
    }
}
customElements.define('carta-memoria', CartaMemoria);

// Juego de memoria
const JuegoMemoria = {
    parejasSeleccionadas: [],

    verificarPareja() {
        const [carta1, carta2] = this.parejasSeleccionadas;
        if (carta1._valor !== carta2._valor) {
            carta1.ocultar();
            carta2.ocultar();
        }
        this.parejasSeleccionadas = [];
    }
};

const iniciarJuego = async () => {
    const valores = ['🍎', '🍌', '🍇', '🍉', '🍓', '🍍', '🍎', '🍌', '🍇', '🍉', '🍓', '🍍'];
    valores.sort(() => Math.random() - 0.5);
    const tablero = document.getElementById('tablero');
    tablero.innerHTML = '';

    for (let valor of valores) {
        const carta = document.createElement('carta-memoria');
        carta.valor = valor;
        tablero.appendChild(carta);
    }
};

document.getElementById('iniciar').addEventListener('click', () => {
    document.getElementById('inicio').style.display = 'none';
    document.getElementById('juego').style.display = 'block';
    iniciarJuego();
});
